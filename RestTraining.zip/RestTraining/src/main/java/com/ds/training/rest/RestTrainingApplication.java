package com.ds.training.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestTrainingApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestTrainingApplication.class, args);
	}
}
